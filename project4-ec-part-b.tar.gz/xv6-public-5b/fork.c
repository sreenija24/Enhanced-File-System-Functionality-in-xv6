#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"
#include "fs.h"
#include "memlayout.h"
#include "param.h"
#include "mmu.h"

#define N  1000
/*
void printf(int fd, char *s, ...)
{
  write(fd, s, strlen(s));
}
*/
void forktest(void)
{
  int n, pid;
  char *buf;

  printf(1, "fork test\n");

  buf = sbrk(0);

  for(n = 0; n < N; n++) {
    pid = fork();
    if(pid < 0)
      break;
    if(pid == 0) {
      // child process
      printf(1, "child %d created\n", getpid());
      // update PTE to be read-only
//if(mprotect((void*)buf, PGSIZE, PTE_P | PTE_U | PTE_W) < 0) {
  //      printf(1, "mprotect failed\n");
    //    exit();
      //}
      // trigger page fault
      buf[0] = 'a';
      printf(1, "child %d wrote to page\n", getpid());
      exit();
    }
  }

  if(n == N) {
    printf(1, "fork claimed to work N times!\n", N);
    exit();
  }

  for(; n > 0; n--) {
    if(wait() < 0) {
      printf(1, "wait stopped early\n");
      exit();
    }
  }

  if(wait() != -1) {
    printf(1, "wait got too many\n");
    exit();
  }

  printf(1, "fork test OK\n");
}

int main(void)
{
  forktest();
  exit();
}
