// Compare the performance of basic fork() and copy-on-write fork()

#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"
#include "memlayout.h"

#define N  100

int main(int argc, char *argv[])
{
  int i, pid, start, end;
  char *buf = malloc(4096);

  start = uptime();
  for(i = 0; i < N; i++) {
    pid = fork();
    if(pid < 0) {
      printf(1, "fork failed\n");
      exit();
    }
    if(pid == 0) {
      // child process
      exit();
    }
  }

  for(i = 0; i < N; i++) {
    wait();
  }

  end = uptime();

  printf(1, "elapsed time: %d ticks\n", end - start);

  free(buf);

  exit();
}

