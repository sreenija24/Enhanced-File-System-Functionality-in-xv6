// Demonstrates the copy-on-write fork implementation

#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[])
{
  int pid = fork();
  if(pid < 0) {
    printf(1, "fork failed\n");
    exit();
  }
  if(pid == 0) {
    // child process
    printf(1, "child process started (pid=%d)\n", getpid());
    char *buf = malloc(4096);
    strcpy(buf, "hello, world");
    printf(1, "child process wrote to buffer: %s\n", buf);
    exit();
  }
  else {
    // parent process
    printf(1, "parent process started (pid=%d)\n", getpid());
    wait();
    printf(1, "parent process finished\n");
    exit();
  }
}
