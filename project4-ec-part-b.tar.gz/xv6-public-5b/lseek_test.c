#include "types.h"
#include "stat.h"
#include "fcntl.h"
#include "user.h"

char buf[512];

int main(int argc, char *argv[]) {
  int fd;

  // Create a new file
  fd = open("test.txt", O_CREATE | O_RDWR);


  // Write some data to the file
  write(fd, "hello", 5);

  // Set the offset to a specific location in the file
  lseek(fd, 10);

  // Write some more data to the file
  write(fd, "world", 5);

  // Set the offset to another location in the file
  lseek(fd, 0);

  // Read some data from the file to verify that the data was written correctly
  read(fd, buf, 15);
  printf(1,"%s\n", buf);

  // Close the file
  close(fd);

  exit();
}
