#include "types.h"
#include "stat.h"
#include "fcntl.h"
#include "user.h"

#define BUFSIZE 512

char buf[BUFSIZE];

int main(int argc, char *argv[]) {
  // Open a file named "targetfile.txt" and create it if it does not exist
  int fd_target = open("targetfile.txt", O_CREATE | O_RDWR);
  if (fd_target < 0) {
    printf(1, "Error opening target file\n");
    exit();
  }

  // Write some data to the target file
  write(fd_target, "Hello, this is an OS.\n", 22);

  // Close the target file
  close(fd_target);

  // Open a file named "linkfile.txt" and create it if it does not exist
  int fd_link = open("linkfile.txt", O_CREATE | O_RDWR);
  if (fd_link < 0) {
    printf(1, "Error opening link file\n");
    exit();
  }

  // Write some data to the link file
  write(fd_link, "World\n", 6);

  // Close the link file


  close(fd_link);

  // Create a symbolic link from "linkfile.txt" to "targetfile.txt"
  char *target_path = "targetfile.txt";
  char *link_path = "linkfile.txt";
  int result = symlink(target_path, link_path);
  if (result == 0) {
    printf(1, "The symbolic link has been created successfully\n");
  } else {
    printf(1, "Error creating symbolic link\n");
    exit();
  }

  // Exit the program
  exit();
  return 0;
}
