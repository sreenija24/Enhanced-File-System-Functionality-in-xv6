#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

#define BLOCKSIZE 512
#define FILESIZE 16523

char buf[BLOCKSIZE];

int main(int argc, char *argv[]) {
  int fd;

  // Create a file
  fd = open("testfile", O_CREATE | O_WRONLY);
  if (fd < 0) {
    printf(2, "Error: cannot create file\n");
    exit();
  }

  // Write to the file until the maximum file size is reached
  for (int i = 0; i < FILESIZE; i++) {
    if (write(fd, buf, BLOCKSIZE) != BLOCKSIZE) {
      printf(2, "Error: write error\n");
      exit();
    }
  }
  close(fd);
  exit();
}